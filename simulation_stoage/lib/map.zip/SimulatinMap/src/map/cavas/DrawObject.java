package map.cavas;

import java.awt.Graphics;

public interface DrawObject {
	public void draw(Graphics g);
}
